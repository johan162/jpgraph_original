<?php

//===================================================
// CLASS BarPlot
// Description: 
//===================================================
class BarPlot extends Plot {
	var $width=0.4; // in percent of major ticks
	var $fill_color=false; // No fill default
	var $ymin=0;
//---------------
// CONSTRUCTOR
	function BarPlot(&$datay) {
		$this->Plot($datay);		
		++$this->numpoints;
	}

//---------------
// PUBLIC METHODS	
	function SetYStart($y) {
		$this->ymin=$y;
	}

	function Legend(&$graph) {
		if( $this->fill_color && $this->legend!="" )
			$graph->legend->Add($this->legend,$this->fill_color);		
	}

	// Gets called before any axis are stroked
	function PreStrokeAdjust(&$graph) {
		// Center each bar within each major tick
		$graph->xaxis->scale->ticks->SetXLabelOffset(0.5);
		$graph->SetTextScaleOff(0.5-$this->width/2);						
		$graph->xaxis->scale->ticks->SupressTickMarks();
	}

	function Min() {
		return array(0,$this->ymin);	// this must be adjusted for log plots
	}
	
	function SetWidth($w) {
		assert($w > 0 && $w <= 1.0);
		$this->width=$w;
	}
	
	function SetFillColor($c) {
		$this->fill_color=$c;
	}
	
	// Method description
	function Stroke(&$img,&$xscale,&$yscale) { 
		$img->SetColor($this->color);
		$img->SetLineWeight($this->weight);
		$numbars=count($this->coords[0]);
		$zp=$yscale->Translate($this->ymin);
		$abswidth=round($this->width*$xscale->scale_factor,0);
		for($i=0; $i<$numbars; $i++) {
			$x=$xscale->Translate($i);
			$pts=array(
				$x,$zp,
				$x,$yscale->Translate($this->coords[0][$i]),
				$x+$abswidth,$yscale->Translate($this->coords[0][$i]),
				$x+$abswidth,$zp);
			if( $this->fill_color ) {
				$img->SetColor($this->fill_color);
				$img->FilledPolygon($pts,4);
				$img->SetColor($this->color);
			}
			$img->Polygon($pts,4);
		}
		return true;
	}
//---------------
// PRIVATE METHODS	
} // Class

//===================================================
// CLASS GroupBarPlot
// Description: 
//===================================================
class GroupBarPlot extends BarPlot {
	var $plots;
	var $width=0.7;
	var $nbrplots=0;
	var $numpoints;
//---------------
// CONSTRUCTOR
	function GroupBarPlot($plots) {
		$this->plots = $plots;
		$this->nbrplots = count($plots);
		$this->numpoints = $plots[0]->numpoints;
	}

//---------------
// PUBLIC METHODS	
	function Legend(&$graph) {
		foreach( $this->plots as $p )
			$p->Legend(&$graph);
	}
	
	function Min() {
		return array(0,$this->ymin);	// Must be adjusted for log plots
	}
	
	function Max() {
		list($xmax,$ymax) = $this->plots[0]->Max();
		foreach($this->plots as $p) {
			list($xm,$ym) = $p->Max();
			$xmax = max($xmax,$xm);
			$ymax = max($ymax,$ym);
		}
		return array($xmax,$ymax);
	}
	
	// Stroke all the bars next to each other
	function Stroke(&$img,&$xscale,&$yscale) { 
		$i=0;
		$tmp=$xscale->off;
		foreach( $this->plots as $p ) {
			$p->ymin=$this->ymin;
			$p->SetWidth($this->width/$this->nbrplots);
			$xscale->off = $tmp+$i*round($xscale->ticks->major_step*$xscale->scale_factor*$this->width/$this->nbrplots);
			$p->Stroke(&$img,&$xscale,&$yscale);
			++$i;
		}
		$xscale->off=$tmp;
	}
//---------------
// PRIVATE METHODS	
} // Class

//===================================================
// CLASS AccBarPlot
// Description: 
//===================================================
class AccBarPlot extends BarPlot {
	var $plots=null,$nbrplots=0,$numpoints=0;
//---------------
// CONSTRUCTOR
	function AccBarPlot($plots) {
		$this->plots = $plots;
		$this->nbrplots = count($plots);
		$this->numpoints = $plots[0]->numpoints;		
	}

//---------------
// PUBLIC METHODS	
	function Legend(&$graph) {
		foreach( $this->plots as $p )
			$p->Legend(&$graph);
	}

	function Max() {
		$accymax=0;
		foreach($this->plots as $p) {
			list($xm,$ym) = $p->Max();
			$xmax = max($xmax,$xm);
			$accymax += $ym;
		}
		return array($xmax,$accymax);
	}

	function Min() {
		return array(0,$this->ymin);	// Must be adjusted for log plots
	}

	// Method description
	function Stroke(&$img,&$xscale,&$yscale) {
		$img->SetLineWeight($this->weight);
		for($i=0; $i<$this->numpoints-1; $i++) {
			$accy=0; 
			for($j=0; $j<$this->nbrplots; ++$j ) {				
				$img->SetColor($this->plots[$j]->color);
				$yt=$yscale->Translate($this->plots[$j]->coords[0][$i]+$accy);
				$accyt=$yscale->Translate($accy);
				$xt=$xscale->Translate($i);
				$abswidth=round($this->width*$xscale->scale_factor,0);
				$pts=array($xt,$accyt,$xt,$yt,$xt+$abswidth,$yt,$xt+$abswidth,$accyt);
				if( $this->plots[$j]->fill_color ) {
					$img->SetColor($this->plots[$j]->fill_color);
					$img->FilledPolygon($pts,4);
					$img->SetColor($this->plots[$j]->color);
				}
				$accy+=$this->plots[$j]->coords[0][$i];
				$img->Polygon($pts,4);
			}
		}
		return true;
	}
//---------------
// PRIVATE METHODS	
} // Class

?>