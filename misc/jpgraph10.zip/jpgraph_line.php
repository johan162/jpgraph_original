<?php
//===================================================
// CLASS LinePlot
// Description: 
//===================================================
DEFINE("MARK_SQUARE",1);
DEFINE("MARK_UTRIANGLE",2);
DEFINE("MARK_DTRIANGLE",3);
DEFINE("MARK_DIAMOND",4);
DEFINE("MARK_CIRCLE",5);

class LinePlot extends Plot{
	var $filled=false;
	var $fill_color;
	var $mark=null;
//---------------
// CONSTRUCTOR
	function LinePlot(&$datay,$datax=false) {
		$this->Plot($datay,$datax);
		$this->mark = new PlotMark();
		$this->mark->SetColor($this->color);
	}
//---------------
// PUBLIC METHODS	
	// Set style, filled or open
	function SetFilled($f=true) {
		$this->filled=$f;
	}
	
	function SetColor($c) {
		parent::SetColor($c);
		$this->mark->SetColor($this->color);
	}
	
	function SetFillColor($c,$f=true) {
		$this->fill_color=$c;
		$this->filled=$f;
	}
	
	function Legend(&$graph) {
		if( $this->filled && $this->legend!="")
			$graph->legend->Add($this->legend,$this->fill_color);				
		else
			parent::Legend($graph);				
	}
	
	function Stroke(&$img,&$xscale,&$yscale) {
		$numpoints=count($this->coords[0]);
		$exist_x = (count($this->coords[1])==$numpoints);

		if( $exist_x )
			$xs=$datax[0];
		else
			$xs=0;

		$img->SetStartPoint($xscale->Translate($xs),
								  $yscale->Translate($this->coords[0][0]));
		
		$cord[] = $xscale->Translate($xs);
		$cord[] = $yscale->Translate($yscale->GetMinVal());
		$cord[] = $xscale->Translate($xs);
		$cord[] = $yscale->Translate($this->coords[0][0]);
		$img->SetColor($this->color);
		$img->SetLineWeight($this->weight);					
		for( $pnts=1; $pnts<$numpoints; ++$pnts) {
			if( $exist_x ) $x=$datax[$pnts];
			else $x=$pnts;
			$xt = $xscale->Translate($x);
			$yt = $yscale->Translate($this->coords[0][$pnts]);
			$cord[] = $xt;
			$cord[] = $yt;
			$img->LineTo($xt,$yt);
		}	
		$cord[] = $xt;
		$cord[] = $yscale->Translate($yscale->GetMinVal());		
		if( $this->filled ) {
			$img->SetColor($this->fill_color);	
			$img->FilledPolygon($cord);
			$img->SetColor($this->color);
			$img->Polygon($cord);
		}
		for($i=2; $i<count($cord)-2; $i+=2) {
			$this->mark->Stroke($img,$cord[$i],$cord[$i+1]);
		}
	}
//---------------
// PRIVATE METHODS	
} // Class


//===================================================
// CLASS AccLinePlot
// Description: 
//===================================================
class AccLinePlot extends Plot {
	var $plots=null,$nbrplots=0,$numpoints=0;
//---------------
// CONSTRUCTOR
	function AccLinePlot($plots) {
		$this->plots = $plots;
		$this->nbrplots = count($plots);
		$this->numpoints = $plots[0]->numpoints;		
	}

//---------------
// PUBLIC METHODS	
	function Legend(&$graph) {
		foreach( $this->plots as $p )
			$p->Legend(&$graph);
	}
	
	function Max() {
		$accymax=0;
		foreach($this->plots as $p) {
			list($xm,$ym) = $p->Max();
			$xmax = max($xmax,$xm);
			$accymax += $ym;
		}
		return array($xmax,$accymax);
	}

	function Min() {
		list($xmin,$ymin)=$this->plots[0]->Min();
		foreach( $this->plots as $p ) {
			list($xm,$ym)=$p->Min();
			$xmin=Min($xmin,$xm);
			$ymin=Min($ymin,$ym);
		}
		return array($xmin,$ymin);	
	}

	// To avoid duplicate of line drawing code here we just
	// change the y-values for each plot and then restore it
	// after we have made the stroke. We must do this copy since
	// it wouldn't be possible to create an acc line plot
	// with the same graphs, i.e AccLinePlot(array($pl,$pl,$pl));
	// since this method would have a side effect.
	function Stroke(&$img,&$xscale,&$yscale) {
		$img->SetLineWeight($this->weight);
		// Allocate array
		$coords[$this->nbrplots][$this->numpoints]=0;
		for($i=0; $i<$this->numpoints; $i++) {
			$coords[0][$i]=$this->plots[0]->coords[0][$i]; 
			$accy=$coords[0][$i];
			for($j=1; $j<$this->nbrplots; ++$j ) {
				$coords[$j][$i] = $this->plots[$j]->coords[0][$i]+$accy; 
				$accy = $coords[$j][$i];
			}
		}
		for($j=$this->nbrplots-1; $j>=0; --$j) {
			$p=$this->plots[$j];
			for( $i=0; $i<$this->numpoints; ++$i) {
				$tmp[$i]=$p->coords[0][$i];
				$p->coords[0][$i]=$coords[$j][$i];
			}
			$p->Stroke($img,$xscale,$yscale);
			for( $i=0; $i<$this->numpoints; ++$i) 
				$p->coords[0][$i]=$tmp[$i];
			$p->coords[0][]=$tmp;
		}
	}

//---------------
// PRIVATE METHODS	
} // Class

//===================================================
// CLASS PlotMark
// Description: 
//===================================================
class PlotMark {
	var $type=-1;
	var $color="black", $width=7;
//	--------------
// CONSTRUCTOR
	function PlotMark() {
	}
//---------------
// PUBLIC METHODS	
	function SetType($t) {
		$this->type = $t;
	}
	
	function SetColor($c) {
		$this->color=$c;
	}
	
	function SetWidth($w) {
		$this->width=$w;
	}
	
	function Stroke(&$img,$x,$y) {
		$dx=round($this->width/2,0);
		$dy=round($this->width/2,0);
		$pts=0;		
		switch( $this->type ) {
			case MARK_SQUARE:
			$c[]=$x-$dx;$c[]=$y-$dy;
			$c[]=$x+$dx;$c[]=$y-$dy;
			$c[]=$x+$dx;$c[]=$y+$dy;
			$c[]=$x-$dx;$c[]=$y+$dy;
			$pts=4;
			break;
			case MARK_UTRIANGLE:
			++$dx;++$dy;
			$c[]=$x-$dx;$c[]=$y+0.87*$dy;	// tan(60)/2*$dx
			$c[]=$x;$c[]=$y-0.87*$dy;
			$c[]=$x+$dx;$c[]=$y+0.87*$dy;
			$pts=3;
			break;
			case MARK_DTRIANGLE:
			++$dx;++$dy;			
			$c[]=$x;$c[]=$y+0.87*$dy;	// tan(60)/2*$dx
			$c[]=$x-$dx;$c[]=$y-0.87*$dy;
			$c[]=$x+$dx;$c[]=$y-0.87*$dy;
			$pts=3;
			break;				
			case MARK_DIAMOND:
			$c[]=$x;$c[]=$y+$dy;
			$c[]=$x-$dx;$c[]=$y;
			$c[]=$x;$c[]=$y-$dy;
			$c[]=$x+$dx;$c[]=$y;
			$pts=4;
			break;				
		}
		if( $pts>0 ) {
			$img->SetColor($this->color);
			$img->FilledPolygon($c,$pts);
		}
		elseif( $this->type==MARK_CIRCLE ) {
			++$dx;++$dy;
			$img->Arc($x,$y,$this->width,$this->width,0,360);
		}
	}
//---------------
// PRIVATE METHODS	
} // Class

?>
