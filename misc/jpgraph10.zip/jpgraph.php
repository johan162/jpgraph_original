<?php
/*=======================================================================
// File: 		JPGRAPH.PHP
// Descr: 		PHP4 Graph Plotting library
// Created: 	2001-01-08
//	Last edit:	2001-01-31	
// By:			Johan Persson
// Ver:			1.0
//
//------------------------------------------------------------------------
// Changelog:
//	When		Who			What
//========================================================================
*/

// Should we try to read from the cahce? Set to false to bypass the
// reading of the cache and always re-generate the image and save it in
// the cache.
DEFINE("READ_CACHE",true);

// The full name of directory to be used as a cache. This directory MUST
// be readable and writable for PHP
DEFINE("CACHE_DIR","./jpgraph_cache");

//Definitions for internal font
DEFINE("FONT0",1);
DEFINE("FONT1",2);
DEFINE("FONT1_BOLD",3);
DEFINE("FONT2",4);
DEFINE("FONT2_BOLD",5);

// Tick density
DEFINE("TICKD_DENSE",1);
DEFINE("TICKD_NORMAL",2);
DEFINE("TICKD_SPARSE",3);
DEFINE("TICKD_VERYSPARSE",4);

// Side for ticks and labels
DEFINE("SIDE_LEFT",-1);
DEFINE("SIDE_RIGHT",1);

// Legend type stacked vertical or horizontal
DEFINE("LEGEND_VERT",0);
DEFINE("LEGEND_HOR",1);


//===================================================
// CLASS GRAPH
// Description: Main class to handle graphs
//===================================================
class Graph {
	var $cache=null;
	var $img=null;
	var $plots=array(),$y2plots=array();
	var $xscale=null,$yscale=null,$y2scale=null;
	var $cache_name;
	var $xgrid=null,$ygrid=null,$y2grid=null;
	var $doframe=true,$frame_color=array(0,0,0), $frame_weight=1;
	var $boxed=false, $box_color=array(0,0,0), $box_weight=1;	
	var $doshadow=false,$shadow_width=4,$shadow_color=array(102,102,102);
	var $xaxis=null,$yaxis=null, $y2axis=null;
	var $margin_color=array(198,198,198);
	var $plotarea_color=array(255,255,255);
	var $title = false;
	var $axtype="linlin";
	var $xtick_factor,$xtick_factor;
	var $texts=null;
	var $text_scale_off=0;
//---------------
// CONSTRUCTOR
	function Graph($aWidth=300,$aHeight=200,$aCachedName="") {
		$this->img = new Image($aWidth,$aHeight);
		$this->cache = new ImgStreamCache($this->img);
		$this->title = new Text("");
		$this->legend = new Legend();
		
		if( $aCachedName!="" && READ_CACHE )
			if( $this->cache->GetAndStream($aCachedName) )
				exit();
		$this->cache_name = $aCachedName;
		
		$this->SetTickDensity(); // Normal density
	}
//---------------
// PUBLIC METHODS	
	// Add a plot object to the graph
	function Add(&$aPlot) {
		$this->plots[] = &$aPlot;
		return true;
	}
	
	function AddY2(&$aPlot) {
		$this->y2plots[] = &$aPlot;
		return true;
	}
	
	function AddText(&$txt) {
		$this->texts[] = &$txt;
	}
	
	function SetBox($box=true,$color=array(0,0,0),$weight=1) {
		$this->boxed = $box;
		$this->box_weight = $weight;
		$this->box_color = $color;
	}
	
	function SetColor($col) {
		$this->plotarea_color=$col;
	}
	
	function SetMarginColor($col) {
		$this->margin_color=$col;
	}
	
	function SetFrame($frame=true,$color=array(0,0,0),$weight=1) {
		$this->doframe = $frame;
		$this->frame_color = $color;
		$this->frame_weight = $weight;
	}
		
	function SetShadow($aShadow=true,$aShadowWidth=5,$aShadowCol=array(102,102,102)) {
		$this->doshadow = $aShadow;
		$this->shadow_color = $aShadowCol;
		$this->shadow_width = $aShadowWidth;
	}

	// Specify scale
	function SetScale($axtype,$ymin=1,$ymax=1,$xmin=1,$xmax=1) {
		$this->axtype = $axtype;
		if( $axtype ==  "linlin" || $axtype == "textlin" ) {
			$this->xscale = new LinearScale($xmin,$xmax,"x");
			$this->yscale = new LinearScale($ymin,$ymax);						
		}
		elseif( $axtype ==  "linlog" || $axtype == "textlog" ) {
			$this->xscale = new LinearScale($xmin,$xmax,"x");
			$this->yscale = new LogScale($ymin,$ymax);			
		}
		elseif( $axtype ==  "loglog" ) {			
			$this->xscale = new LogScale($xmin,$xmax,"x");
			$this->yscale = new LogScale($ymin,$ymax);
		}		
		elseif( $axtype ==  "loglin" ) {			
			$this->xscale = new LogScale($xmin,$xmax,"x");
			$this->yscale = new LinScale($ymin,$ymax);
		}		
		else die("Unsupported axis type: $axtype<br>");

		$this->xscale->Init($this->img);
		$this->yscale->Init($this->img);						
					
		$this->xscale->ticks->SetPrecision(0);
		
		$this->xaxis = new Axis($this->img,$this->xscale);
		$this->yaxis = new Axis($this->img,$this->yscale);
		$this->xgrid = new Grid($this->xaxis);
		$this->ygrid = new Grid($this->yaxis);	
		$this->ygrid->Show();
			
	}
	
	// Specify secondary scale
	function SetY2Scale($axtype="lin",$min=1,$max=1) {
		if( $axtype=="lin" ) 
			$this->y2scale = new LinearScale($min,$max);
		elseif( $axtype=="log" ) {
			$this->y2scale = new LogScale($min,$max);
		}
		else die("Unsupported Y2 axis type: $axtype<br>");
			
		$this->y2scale->Init($this->img);	
		$this->y2axis = new Axis($this->img,$this->y2scale);
		$this->y2axis->scale->ticks->SetDirection(-1); 
		$this->y2axis->SetLabelPos(1); // Labels to right off axis
		
		// Deafult position is the max x-value
		$this->y2axis->SetPos($this->xscale->GetMaxVal());
		$this->y2grid = new Grid($this->y2axis);							
	}
	
	// Specify density of ticks when autoscaling 'normal', 'dense', 'sparse', 'verysparse'
	// The dividing factor have been determined heuristic according to my estetic sense
	// y.m.m.v !
	// if parameter $x is true the density will also affect the x-axis.
	function SetTickDensity($densy=TICKD_NORMAL,$densx=TICKD_NORMAL) {
		$this->xtick_factor=30;
		$this->ytick_factor=25;		
		switch( $densy ) {
			case TICKD_DENSE:
				$this->ytick_factor=12;			
				break;
			case TICKD_NORMAL:
				$this->ytick_factor=25;			
				break;
			case TICKD_SPARSE:
				$this->ytick_factor=40;			
				break;
			case TICKD_VERYSPARSE:
				$this->ytick_factor=100;			
				break;		
			default:
				die("Unsupported Tick density: $densy");
		}
		switch( $densx ) {
			case TICKD_DENSE:
				$this->xtick_factor=18;							
				break;
			case TICKD_NORMAL:
				$this->xtick_factor=30;			
				break;
			case TICKD_SPARSE:
				$this->xtick_factor=45;					
				break;
			case TICKD_VERYSPARSE:
				$this->xtick_factor=60;								
				break;		
			default:
				die("Unsupported Tick density: $densx");
		}		
	}
	
	// Stroke the graph
	function Stroke() {		
		// Do any pre-stroke adjustment that is needed by the different plot types
		// (i.e bar plots want's to add an offset to the x-labels etc)
		foreach( $this->plots as $p ) {			
			$p->PreStrokeAdjust(&$this);
			$p->Legend(&$this);
		}		
		if( $this->y2scale != null )
			foreach( $this->y2plots as $p ) {	
				$p->PreStrokeAdjust(&$this);
				$p->Legend(&$this);
			}			

		// Bail out if any of the Y-axis not been specified and
		// has no plots. (This means it is impossible to do autoscaling and
		// no other scale was given so we can't possible draw anything). If you use manual
		// scaling you also have to supply the tick steps as well.
		if( (!$this->yscale->IsSpecified() && count($this->plots)==0) ||
			($this->y2scale!=null && !$this->y2scale->IsSpecified() && count($this->y2plots)==0) ) {
			die("<strong>Can't draw unspecified Y-scale.</strong><br>
			You have either:
			<br>* Specified an Y axis for autoscaling but have not supplied any plots 
			<br>* Specified an Y axis with min and max but forgotten to specify tick steps.");
		}
		
		// Bail out if no plots and no specified X-scale
		if( (!$this->xscale->IsSpecified() && count($this->plots)==0 && count($this->y2plots)==0) )
			die("<strong>Can't draw unspecified X-scale.</strong><br>No plots.<br>");

		//Check if we should autoscale y-axis
		if( !$this->yscale->IsSpecified() && count($this->plots)>0 ) {
			list($min,$max) = $this->GetPlotsYMinMax($this->plots);
			$this->yscale->AutoScale($this->img,$min,$max,$this->img->plotheight/$this->ytick_factor);
		}

		if( $this->y2scale != null) 
			if( !$this->y2scale->IsSpecified() && count($this->y2plots)>0 ) {
				list($min,$max) = $this->GetPlotsYMinMax($this->y2plots);
				$this->y2scale->AutoScale($this->img,$min,$max,$this->img->plotheight/$this->ytick_factor);
			}			
				
		//Check if we should autoscale x-axis
		if( !$this->xscale->IsSpecified() ) {
			$max=0;
			foreach( $this->plots as $p ) 
				$max=max($max,$p->numpoints-1);
			$min=0;
			if( substr($this->axtype,0,4) == "text" ) {
				$this->xscale->Update($this->img,0,$max);
				$this->xscale->ticks->Set($this->xaxis->label_step,1);
				$this->xscale->ticks->SupressMinorTickMarks();
			}
			else
				$this->xscale->AutoScale($this->img,$min,$max,$this->img->plotwidth/$this->xtick_factor);
			
			//Adjust position of y-axis and y2-axis to minimum/maximum of x-scale
			$this->yaxis->SetPos($this->xscale->GetMinVal());
			if( $this->y2axis != null ) {
				$this->y2axis->SetPos($this->xscale->GetMaxVal());
				$this->y2axis->SetTitleSide(SIDE_RIGHT);
			}
		}		
		
		// If we have a negative values and x-axis position is at 0
		// we need to supress the first and possible the last tick since
		// they will be drawn on top of the y-axis (and possible y2 axis)
		if( $this->yscale->GetMinVal() < 0 && $this->xscale->pos == 0 ) {
			$this->yscale->ticks->SupressZeroLabel(false);
			$this->xscale->ticks->SupressFirst();
			if( $this->y2axis != null ) {
				$this->xscale->ticks->SupressLast();
			}
		}
		
		$this->StrokeFrame();
		$this->img->SetColor($this->plotarea_color);		
		$this->img->FilledRectangle($this->img->left_margin,
											$this->img->top_margin,
											$this->img->width-$this->img->right_margin,
											$this->img->height-$this->img->bottom_margin);		

		$this->xaxis->Stroke($this->yscale);		
		$this->xgrid->Stroke();

		$this->yaxis->Stroke($this->xscale);		
		$this->ygrid->Stroke();	

		if( $this->y2axis != null ) {		
			$this->y2axis->Stroke($this->xscale); 				
			$this->y2grid->Stroke();
		}
		
		// 
		$oldoff=$this->xscale->off;
		if(substr($this->axtype,0,4)=="text") {
			$this->xscale->off += 
				ceil($this->xscale->scale_factor*$this->text_scale_off*$this->xscale->ticks->minor_step);
		}
				
		foreach( $this->plots as $p ) {			
			$p->Stroke($this->img,$this->xscale,$this->yscale);
			$p->StrokeMargin($this->img);
		}		
		
		if( $this->y2scale != null )
			foreach( $this->y2plots as $p ) {	
				$p->Stroke($this->img,$this->xscale,$this->y2scale);
			}		

		$this->xscale->off=$oldoff;
		
		// Finally draw the axis again since some plots may have nagged
		// the axis in the edges.
		$this->yaxis->Stroke($this->xscale);					
		$this->xaxis->Stroke($this->yscale);
		if( $this->y2scale != null) 
			$this->y2axis->Stroke($this->xscale); 	
		
		// Should we draw a box around the plot area?
		if( $this->boxed ) {
			$this->img->SetLineWeight($this->box_width);
			$this->img->SetColor($this->box_color);
			$this->img->Rectangle(
				$this->img->left_margin,$this->img->top_margin,
				$this->img->width-$this->img->right_margin,
				$this->img->height-$this->img->bottom_margin);
		}						
		
		// Stroke title
		$this->title->Center($this->img->left_margin,$this->img->width-$this->img->right_margin,5);
		$this->title->Stroke($this->img);
		
		// Stroke legend
		$this->legend->Stroke($this->img,$this->xscale,$this->yscale);
		
		// Stroke any user added text objects
		if( $this->texts != null )
			foreach( $this->texts as $t) {
				$t->x *= $this->img->width;
				$t->y *= $this->img->height;
				$t->Stroke($this->img);
			}
				
		// Finally stream the generated picture					
		$this->cache->PutAndStream($this->img,$this->cache_name);		
	}
	
//---------------
// PRIVATE METHODS	
	function SetTextScaleOff($o) {
		$this->text_scale_off = $o;
	}
	
	function GetPlotsYMinMax(&$plots) {
		list($xmax,$max) = $plots[0]->Max();
		list($xmin,$min) = $plots[0]->Min();
		foreach( $plots as $p ) {
			list($xmax,$ymax)=$p->Max();
			list($xmin,$ymin)=$p->Min();
			$max=max($max,$ymax);
			$min=min($min,$ymin);
		}		
		return array($min,$max);
	}

	function StrokeFrame() {
		if( $this->doshadow ) {
			$this->img->SetColor($this->frame_color);			
			$this->img->ShadowRectangle(0,0,$this->img->width,$this->img->height,
												 $this->margin_color,$this->shadow_width);
		}
		else {
			$this->img->SetLineWeight($this->frame_weight);
			$this->img->SetColor($this->margin_color);
			$this->img->FilledRectangle(1,1,$this->img->width-2,$this->img->height-2);		
			$this->img->SetColor($this->frame_color);
			$this->img->Rectangle(0,0,$this->img->width-1,$this->img->height-1);		
		}
	}
} // Class

//===================================================
// CLASS Text
// Description: Arbitrary text that can be added to the graph
//===================================================
class Text {
	var $t,$x=0,$y=0,$halign="left",$color=array(0,0,0);
	var $size=2,$name="internal",$hide=false,$dir="h";
	var $boxed=false;	// Should the text be boxed
//---------------
// CONSTRUCTOR
	function Text($txt="",$x=0,$y=0) {
		$this->t = $txt;
		$this->x = $x;
		$this->y = $y;
	}
//---------------
// PUBLIC METHODS	
	function Set($t) {
		$this->t = $t;
	}
	
	function Pos($x=0,$y=0,$halign="left") {
		$this->x = $x;
		$this->y = $y;
		$this->halign = $halign;
	}
	
	function SetBox($fcolor=array(255,255,255),$bcolor=array(0,0,0),$shadow=false) {
		if( $fcolor==false )
			$this->boxed=false;
		else
			$this->boxed=true;
		$this->fcolor=$fcolor;
		$this->bcolor=$bcolor;
		$this->shadow=$shadow;
	}
	
	function Hide($f=true) {
		$this->hide=$f;
	}
	
	function SetFont($size,$name="internal") {
		$this->size=$size;
		$this->name=$name;
	}
	
	function Center($left,$right,$y=false) {
		$this->x = $left + ($right-$left	)/2;
		$this->halign = "center";
		if( is_numeric($y) )
			$this->y = $y;		
	}
	
	function SetColor($col) {
		$this->color = $col;
	}
	
	function SetOrientation($d="h") {
		$this->dir=$d;	
	}
	
	function GetWidth(&$img) {
		$img->SetFont($this->size,$this->name);		
		return $img->GetTextWidth($this->t);
	}
	
	function GetFontHeight(&$img) {
		$img->SetFont($this->size,$this->name);		
		return $img->GetFontHeight();
	}
	
	function Stroke(&$img) {
		$img->SetColor($this->color);	
		$img->SetFont($this->size,$this->name);
		
		// Impedance adjustment..
		if( $this->fcolor=="nofill" ) $this->fcolor=false;
		
		if( $this->boxed ) {
			$img->StrokeBoxedText($this->x,$this->y,$this->t,$this->halign,$this->dir,
				$this->fcolor,$this->bcolor,$this->shadow);
		}
		else
			$img->StrokeText($this->x,$this->y,$this->t,$this->halign,$this->dir);
	}
} // Class

//===================================================
// CLASS Grid
// Description: responsible for drawing grid lines
//===================================================
class Grid {
	var $img;
	var $scale;
	var $grid_color=array(196,196,196);
	var $type="solid";
	var $show=false, $showMinor=false,$weight=1;
//---------------
// CONSTRUCTOR
	function Grid(&$axis) {
		$this->scale = &$axis->scale;
		$this->img = &$axis->img;
	}
	
	function SetColor($color) {
		$this->grid_color=$color;
	}
	
	function SetWeight($w) {
		$this->weight=$w;
	}
	
	// Specify if grid should be dashed, dotted or solid
	function SetLineStyle($type) {
		$this->type = $type;
	}
	
	function Show($show=true,$minor=false) {
		$this->show=$show;
		$this->showMinor=$minor;
	}
		
	function Stroke() {
		if( $this->showMinor ) 
			$this->_DoStroke($this->scale->ticks->ticks_pos);
		else
			$this->_DoStroke($this->scale->ticks->maj_ticks_pos);
	}
	
	// Draw the grid
	function _DoStroke(&$ticks_pos) {
		if( !$this->show )
			return;	
		$this->img->SetColor($this->grid_color);
		$this->img->SetLineWeight($this->weight);
		$nbrgrids = count($ticks_pos);					
		if( $this->scale->type=="y" ) {
			$xl=$this->img->left_margin;
			$xr=$this->img->width-$this->img->right_margin;
			for($i=0; $i<$nbrgrids; ++$i) {
				$y=$ticks_pos[$i];
				if( $this->type == "solid" )
					$this->img->Line($xl,$y,$xr,$y);
				elseif( $this->type == "dotted" )
					$this->img->DashedLine($xl,$y,$xr,$y,1,6);
				elseif( $this->type == "dashed" )
					$this->img->DashedLine($xl,$y,$xr,$y,2,4);
				elseif( $this->type == "longdashed" )
					$this->img->DashedLine($xl,$y,$xr,$y,8,6);
			}
		}
				
		if( $this->scale->type=="x" ) {	
			$yu=$this->img->top_margin;
			$yl=$this->img->height-$this->img->bottom_margin;
			$x=$ticks_pos[0];
			$limit=$this->img->width-$this->img->right_margin;
			$i=0;
			// We must also test for limit since we might have
			// an offset and the number of ticks is calculated with
			// assumption offset==0 so we might end up drawing one
			// to many gridlines
			while( $x<$limit && $i<count($ticks_pos)) {
				if( $this->type == "solid" )				
					$this->img->Line($x,$yl,$x,$yu);
				elseif( $this->type == "dotted" )
					$this->img->DashedLine($x,$yl,$x,$yu,1,6);
				elseif( $this->type == "dashed" )
					$this->img->DashedLine($x,$yl,$x,$yu,2,4);
				elseif( $this->type == "longdashed" )
					$this->img->DashedLine($x,$yl,$x,$yu,8,6);									
				$x=$ticks_pos[++$i];									
			}
		}		
		return true;
	}
//---------------
// PRIVATE METHODS		

} // Class

//===================================================
// CLASS Axis
// Description: Defines X and Y axis
//===================================================
class Axis {
	var $pos = false;
	var $weight=1;
	var $color=array(0,0,0);
	var $img=null,$scale=null; 
	var $hide=false;
	var $ticks_label=false;
	var $show_first_label=true;
	var $label_step=1; // Used by a text axis to specify what multiple of major steps
							 // should be labeled.
	var $title=null,$title_adjust="high",$title_xmargin=0,$title_ymargin=20,$title_side=SIDE_LEFT;
	var $font="internal",$font_size=2;
	
//---------------
// CONSTRUCTOR
	function Axis(&$img,&$aScale,$color=array(0,0,0)) {
		$this->img = &$img;
		$this->scale = &$aScale;
		$this->color = $color;
		$this->title=new Text("");
		if( $aScale->type=="y" ) {
			$this->title_adjust="middle";
			$this->title->SetOrientation("v");
		}
	}
//---------------
// PUBLIC METHODS	
	function HideFirstTickLabel($flag=false) {
		$this->show_first_label=$flag;
	}
	
	function Hide($h=true) {
		$this->hide=$h;
	}

	function SetWeight($weight) {
		$this->weight = $weight;
	}

	function SetColor($color) {
		$this->color = $color;
	}
	
	function SetTitle($t,$adj="high") {
		$this->title->Set($t);
		$this->title_adjust=$adj;
	}
	
	function SetTickLabels($l) {
		$this->ticks_label = $l;
	}
	
	function SetTextTicks($step,$start=0) {
		$this->scale->ticks->SetTextLabelStart($start);
		$this->label_step=$step;
	}
	
	function SetLabelPos($pos) {
		$this->labelPos=$pos;
	}
	
	function SetFont($size,$font="internal") {
		$this->font_size=$size;
		$this->font=$font;
	}
	
	function SetTitleSide($s) {
		$this->title_side = $s;
	}
	
	function Stroke($otherAxisScale) {		
		if( $this->hide ) return;
		
		if( is_numeric($this->pos) ) {
			$pos=$otherAxisScale->Translate($this->pos);
		}
		else {	// Default to minimum of other scale if pos not set
			if( $otherAxisScale->GetMinVal() >= 0 || $this->pos=="min" ) {
				$pos = $otherAxisScale->scale_abs[0];
			}
			else { // If negative set x-axis at 0
				$this->pos=0;
				$pos=$otherAxisScale->Translate(0);
			}
		}	
		$this->img->SetColor($this->color);
		// Draw x-axis
		if( $this->scale->type == "x" ) {
			$this->img->FilledRectangle($this->img->left_margin,$pos,
							  $this->img->width-$this->img->right_margin,$pos+$this->weight-1);
			$y=$pos+$this->img->GetFontHeight()+$this->title_xmargin;	
			if( $this->title_adjust=="high" )
				$this->title->Pos($this->img->width-$this->img->right_margin,$y,"right");
			elseif($this->title_adjust=="middle") {
				$this->title->Pos(($this->img->width-$this->img->left_margin-$this->img->right_margin)/2+$this->img->left_margin,$y,"center");
			}
			elseif($this->title_adjust=="low")
				$this->title->Pos($this->img->left_margin,$y,"left");
		}
		elseif( $this->scale->type == "y" ) {
			// Draw y-axis. 
			// Add line weight to the height of the axis since
			// the x-axis could have a width>1 and we want the axis to fit nicely
			// together.
			$this->img->FilledRectangle($pos-$this->weight+1,$this->img->top_margin,
							  $pos,$this->img->height-$this->img->bottom_margin+$this->weight-1);
			$x=$pos ;
			if( $this->title->dir=="h" ) {
				if( $this->title_side == SIDE_LEFT )
					$x -= $this->title->GetWidth($this->img)+$this->title_ymargin;
				else
					$x += $this->title_ymargin;
				if( $this->title_adjust=="high" )
					$this->title->Pos($x,$this->img->top_margin-$this->title->GetFontHeight($this->img)/2);
				elseif($this->title_adjust=="middle") {
					$this->title->Pos($x,($this->img->height-$this->img->top_margin-$this->img->bottom_margin)/2+$this->img->top_margin-$this->title->GetFontHeight($this->img)/2);
				}
				elseif($this->title_adjust=="low")
					$this->title->Pos($x,$this->img->height-$this->img->bottom_margin-$this->title->GetFontHeight($this->img));
				
			}
			else { // Vertical text
				if( $this->title_side == SIDE_LEFT )
					$x -= $this->title->GetFontHeight($this->img)+$this->title_ymargin;
				else
					$x += $this->title_ymargin;
				if( $this->title_adjust=="high" )
					$this->title->Pos($x,$this->img->top_margin+$this->title->GetWidth($this->img));
				elseif($this->title_adjust=="middle") {
					$this->title->Pos($x,($this->img->height-$this->img->top_margin-$this->img->bottom_margin)/2+$this->img->top_margin+$this->title->GetWidth($this->img)/2);
				}
				elseif($this->title_adjust=="low")
					$this->title->Pos($x,$this->img->height-$this->img->bottom_margin);				
			}										  
		}
		$this->img->SetLineWeight($this->weight);
		$this->img->SetColor($this->color);		
		$this->scale->ticks->Stroke($this->img,$this->scale,$pos);
		$this->_StrokeLabels($pos);
		$this->title->Stroke($this->img);
	}

	// Position for axis line on the "other" scale
	function SetPos($pos) {
		$this->pos=$pos;
	}
//---------------
// PRIVATE METHODS	
	function _StrokeLabels($pos,$minor=false) {
		$this->img->SetFont($this->font_size,$this->font);
		$yoff=$this->img->GetFontHeight()/2;
		if( $minor ) { // Normally minor ticks do NOT have any labels
			$nbr = count($this->scale->ticks->ticks_label);
			for( $i=0; $i<$nbr ; $i++ ) {
				if( $this->ticks_label )
					$label=$this->ticks_label[$i];
				else
					$label=$this->scale->ticks->ticks_label[$i];
				if( $this->scale->type == "x" ) {
					$this->img->StrokeText($this->scale->ticks->ticks_pos[$i],$pos,$label,"center");
				} else {
					if( $this->labelPos == 0 ) // To the left of y-axis
						$this->img->StrokeText($pos,$this->scale->ticks->ticks_pos[$i]-$yoff,$label,"right");
					else // To the right of the y-axis
						$this->img->StrokeText($pos,$this->scale->ticks->ticks_pos[$i]-$yoff,$label);
				}
			}
		}
		else {
			$nbr = count($this->scale->ticks->maj_ticks_label);
			if( $this->show_first_label ) $start=0;
			else $start=1;
			
			// Note. the $limit is only used for the x axis since we
			// might otherwhise overshoot if the scale has been centered
			if( $this->scale->type=="x" )
				$limit=$this->img->width-$this->img->right_margin;
			else
				$limit=$this->img->height;
				
			$i=$start; 
			$tpos=$this->scale->ticks->maj_ticks_pos[$i];			
			while( $i<$nbr && $tpos<=$limit ) {
				if( $this->ticks_label )
					$label=$this->ticks_label[$i];
				else
					$label=$this->scale->ticks->maj_ticks_label[$i];
				if( $this->scale->type == "x" ) {
					$this->img->StrokeText($tpos,$pos,$label,"center");
				}
				else {
					if( $this->labelPos == 0 ) // To the left of y-axis					
						$this->img->StrokeText($pos-2,$tpos-$yoff,$label,"right");					
					else // To the right of the y-axis
						$this->img->StrokeText($pos+4,$tpos-$yoff,$label);					
				}
				$tpos=$this->scale->ticks->maj_ticks_pos[++$i];				
			}								
		}			
	}		
} // Class

//===================================================
// CLASS Ticks
// Description: Abstract base class for drawing linear and logarithmic
// tick marks on axis
//===================================================
class Ticks {
	var $minor_abs_size=3, $major_abs_size=5;
	var $direction=1; // Should ticks be in(=1) the plot area or outside (=-1)?
	var $scale;
	var $ticks_pos=array(); // Save position of minor ticks
	var $maj_ticks_pos=array(); // Save position of major ticks
	var $ticks_label=array(), $maj_ticks_label=array();
	var $is_set=false;
	var $precision=-1;
	var $supress_zerolabel=false,$supress_first=false;
	var $supress_last=false,$supress_tickmarks=false,$supress_minor_tickmarks=false;
//---------------
// CONSTRUCTOR
	function Ticks(&$aScale) {
		$this->scale=&$aScale;
	}

//---------------
// PUBLIC METHODS	
	function GetMinTickAbsSize() {
		return $this->minor_abs_size;
	}

	function SupressZeroLabel($z=true) {
		$this->supress_zerolabel=$z;
	}
	
	function SupressMinorTickMarks($tm=true) {
		$this->supress_minor_tickmarks=$tm;
	}
	
	function SupressTickMarks($tm=true) {
		$this->supress_tickmarks=$tm;
	}
	
	function SupressFirst($ft=true) {
		$this->supress_first=$ft;
	}
	
	function SupressLast($lt=true) {
		$this->supress_last=$lt;
	}
	
	function GetMajTickAbsSize() {
		return $this->major_abs_size;		
	}
	
	function IsSpecified() {
		return $this->is_set;
	}
	
	function Set($maj,$min) {
		// Should be implemented by the concrete subclass
		// if any action is wanted.
	}
	
	function SetPrecision($p) {
		$this->precision=$p;
	}
	
	function SetDirection($dir=1) {
		if( $dir>=0) 
			$this->direction=1;
		else
			$this->direction = -1;
	}
} // Class

//===================================================
// CLASS LinearTicks
// Description: Draw linear ticks on axis
//===================================================
class LinearTicks extends Ticks {
	var $minor_step=1, $major_step=2;
	var $xlabel_offset=0;
	var $text_label_start=0;
//---------------
// CONSTRUCTOR
	function LinearTicks() {
	}

//---------------
// PUBLIC METHODS	
	function GetMajor() {
		return $this->major_step;
	}
	
	function GetMinor() {
		return $this->minor_step;
	}
	
	// Set Minor and Major ticks
	function Set($maj_step,$min_step) {
		$this->major_step=$maj_step;
		$this->minor_step=$min_step;
		$this->is_set = true;
	}

	function Stroke(&$img,&$scale,$pos) {
		$maj_step_abs = $scale->scale_factor*$this->major_step;		
		$min_step_abs = $scale->scale_factor*$this->minor_step;		
		$limit = $scale->scale_abs[1];	
		$nbrmajticks=floor(($scale->GetMaxVal()-$scale->GetMinVal())/$this->major_step)+1;
		$first=0;
		// If precision hasn't been specified set it to a sensible value
		if( $this->precision==-1 ) { 
			if(abs(floor(log10($this->major_step)))>0)
				$precision=0;
			else 
				$precision=abs(floor(log10($this->major_step)));
		}
		else
			$precision = $this->precision;
		if( $scale->type == "x" ) {
			// Draw the major tick marks
			$yu = $pos - $this->direction*$this->GetMajTickAbsSize();
			$label = $scale->GetMinVal()+$this->text_label_start;	
			$start_abs=$scale->scale_factor*$this->text_label_start;
			$nbrmajticks=ceil(($scale->GetMaxVal()-$scale->GetMinVal()-$this->text_label_start)/$this->major_step)+1;			
			for( $i=0; $label<=$scale->GetMaxVal(); ++$i ) {
				$x=$scale->scale_abs[0]+$start_abs+
					$i*$maj_step_abs+$this->xlabel_offset*$min_step_abs;				
				$this->maj_ticks_pos[$i]=ceil($x);
				$t=round($label*pow(10,$precision),0);
				$l=substr($t,0,strlen($t)-$precision);
				if( $l=="" ) $l="0";
				if( $precision>0 )
					$l.=".".substr($t,strlen($t)-$precision);				
				if( ($this->supress_zerolabel && ($l + 0)==0) ||
				    ($this->supress_first && $i==0) ||
				    ($this->supress_last  && $i==$nbrmajticks-1) )
					$l="";					
				$this->maj_ticks_label[$i]=$l;
				$label+=$this->major_step;
				if(!($this->xlabel_offset > 0 && $i==$nbrmajticks-1) && !$this->supress_tickmarks)
					$img->Line($x,$pos,$x,$yu);
			}
			// Draw the minor tick marks
			
			$yu = $pos - $this->direction*$this->GetMinTickAbsSize();
			$label = $scale->GetMinVal();								
			for( $i=0,$x=$scale->scale_abs[0]; $x<$limit; ++$i ) {
				$x=$scale->scale_abs[0]+$i*$min_step_abs;
				$this->ticks_pos[]=$x;
				$this->ticks_label[]=$label;
				$label+=$this->minor_step;
				if( !$this->supress_tickmarks && !$this->supress_minor_tickmarks)	{						
					$img->Line($x,$pos,$x,$yu); }
			}
		}
		elseif( $scale->type == "y" ) {
			// Draw the major tick marks
			$xr = $pos + $this->direction*$this->GetMajTickAbsSize();
			$label = $scale->GetMinVal();
			for( $i=0; $i<$nbrmajticks; ++$i) {
				$y=$scale->scale_abs[0]+$i*$maj_step_abs;				
				$this->maj_ticks_pos[$i]=$y;
				$t=round($label*pow(10,$precision),0);
				$l=substr($t,0,strlen($t)-$precision);
				if( $l=="" ) $l="0";
				if( $precision>0 )
					$l.=".".substr($t,strlen($t)-$precision);
				if( ($this->supress_zerolabel && ($l + 0)==0) ||
				    ($this->supress_first && $i==0) ||
				    ($this->supress_last  && $i==$nbrmajticks-1) )
					$l="";
				$this->maj_ticks_label[$i]=$l; 
				$label+=$this->major_step;	
				if( !$this->supress_tickmarks )			
					$img->Line($pos,$y,$xr,$y);	
			}
			// Draw the minor tick marks
			$xr = $pos + $this->direction*$this->GetMinTickAbsSize();
			$label = $scale->GetMinVal();	
			for( $i=0,$y=$scale->scale_abs[0]; $y>=$limit; ) {
				$this->ticks_pos[$i]=$y;
				$this->ticks_label[$i]=$label;				
				$label+=$this->minor_step;				
				if( !$this->supress_tickmarks && !$this->supress_minor_tickmarks)			
					$img->Line($pos,$y,$xr,$y);
				++$i;
				$y=$scale->scale_abs[0]+$i*$min_step_abs;								
			}	
		}	
	}
//---------------
// PRIVATE METHODS
	function SetXLabelOffset($o) {
		$this->xlabel_offset=$o;
		if( $o>0 )
			$this->SupressLast();	// The last tick wont fit
	}

	function SetTextLabelStart($s) {
		$this->text_label_start=$s;
	}
	
} // Class



//===================================================
// CLASS LinearScale
// Description: Handle linear scaling between screen and world 
//===================================================
class LinearScale {
	var $scale=array(0,0);
	var $scale_abs=array(0,0);
	var $world_size;	// Plot area size in world coordinates
	var $world_abs_size; // Plot area size in pixels
	var $scale_factor; // Scale factor between world and screen
	var $off; // Offset between image edge and plot area
	var $type; // is this x or y scale ?
	var $ticks=null; // Store ticks
	var $autoscale_min=false; // Forced minimum value, useful to let user force 0 as start and autoscale max
//---------------
// CONSTRUCTOR
	function LinearScale($min=0,$max=0,$type="y") {
		assert($type=="x" || $type=="y" );
		assert($min<=$max);
		
		$this->type=$type;
		$this->scale=array($min,$max);		
		$this->world_size=$max-$min;	
		$this->ticks = new LinearTicks();
		if( $type=="y" )
			$this->ticks->SupressZeroLabel();
	}

//---------------
// PUBLIC METHODS	
	function Init(&$img) {
		$this->InitConstants($img);	
		// We want image to notify us when the margins changes so we 
		// can recalculate the constants.
		// PHP <= 4.04 BUGWARNING: IT IS IMPOSSIBLE TO DO THIS IN THE CONSTRUCTOR
		// SINCE (FOR SOME REASON) IT IS IMPOSSIBLE TO PASS A REFERENCE
		// TO 'this' INSTEAD IT WILL ADD AN ANONYMOUS COPY OF THIS OBJECT WHICH WILL
		// GET ALL THE NOTIFICATIONS. (This took a while to track down...)
		$img->AddObserver("InitConstants",&$this);
	}
	
	// Check if scale is set or if we should autoscale
	// We should do this is either scale or ticks has not been set
	function IsSpecified() {
		if( $this->GetMinVal()==$this->GetMaxVal() ) {		// Scale not set
			return false;
		}
		elseif( $this->ticks->IsSpecified() ) {
			return true;
		}
		return false;
	}
	
	function SetAutoMin($m) {
		$this->autoscale_min=$m;
	}
	
	function GetMinVal() {
		return $this->scale[0];
	}
	
	function GetMaxVal() {
		return $this->scale[1];
	}
		
	function Update(&$img,$min,$max) {
		$this->scale=array($min,$max);		
		$this->world_size=$max-$min;		
		$this->InitConstants($img);					
	}
	
	// Translate between world and screen
	function Translate($a) {
		return $this->off+round(($a*1.0 - $this->GetMinVal()) * $this->scale_factor,0); 
	}
	
	// Calculate autoscale. Used if user hasn't given a scale and ticks
	// $maxsteps is the maximum number of major tickmarks allowed.
	function AutoScale(&$img,$min,$max,$maxsteps,$majend=true) {
		if( is_numeric($this->autoscale_min) ) $min = $this->autoscale_min;
		
		// First get tickmarks as multiples of 0.1, 1, 10, ...	
		list($num1steps,$adj1min,$adj1max,$min1step,$maj1step) = $this->CalcTicks($maxsteps,$min,$max,1,2);
		
		// Then get tick marks as 2:s 0.2, 2, 20, ...
		list($num2steps,$adj2min,$adj2max,$min2step,$maj2step) = $this->CalcTicks($maxsteps,$min,$max,5,2);
		
		// Then get tickmarks as 5:s 0.05, 0.5, 5, 50, ...
		list($num5steps,$adj5min,$adj5max,$min5step,$maj5step) = $this->CalcTicks($maxsteps,$min,$max,2,5);		

		// Check to see whether multiples of 1:s, 2:s or 5:s fit better with
		// the requested number of major ticks		
		$match1=abs($num1steps-$maxsteps);		
		$match2=abs($num2steps-$maxsteps);
		$match5=abs($num5steps-$maxsteps);
		// Compare these three values and see which is the closest match
		// We use a 0.8 weight to gravitate towards multiple of 5:s 
		$r=$this->MatchMin3($match1,$match2,$match5,0.8);
		switch( $r ) {
			case 1:
				$this->Update($img,$adj1min,$adj1max);
				$this->ticks->Set($maj1step,$min1step);		
				break;			
			case 2:
				$this->Update($img,$adj2min,$adj2max);		
				$this->ticks->Set($maj2step,$min2step);
				break;									
			case 3:
				$this->Update($img,$adj5min,$adj5max);
				$this->ticks->Set($maj5step,$min5step);		
				break;			
		}
	}

//---------------
// PRIVATE METHODS	

	// This method recalculates all constants that are depending on the
	// margins in the image. If the margins in the image are changed
	// this method should be called for every scale that is registred with
	// that image. Should really be installed as an observer of that image.
	function InitConstants(&$img) {
		if( $this->type=="x" ) {
			$this->world_abs_size=$img->width - $img->left_margin - $img->right_margin;
			$this->off=$img->left_margin;
			if( $this->world_size > 0 )
				$this->scale_factor=$this->world_abs_size/($this->world_size*1.0);
		}
		else { // y scale
			$this->world_abs_size=$img->height - $img->top_margin - $img->bottom_margin;								
			$this->off=$img->top_margin+$this->world_abs_size;			
			if( $this->world_size > 0 )			
				$this->scale_factor=-$this->world_abs_size/($this->world_size*1.0);							
		}
		$this->scale_abs=array($this->off,$this->off+$this->world_size*$this->scale_factor);	
	}
	
	// Calculate number of ticks steps with a specific division
	// $a is the divisor of 10**x to generate the first maj tick intervall
	// $a=1, $b=2 give major ticks with multiple of 10, ...,0.1,1,10,...
	// $a=5, $b=2 give major ticks with multiple of 2:s ...,0.2,2,20,...
	// $a=2, $b=5 give major ticks with multiple of 5:s ...,0.5,5,50,...
	// We return a vector of
	// 	[$numsteps,$adjmin,$adjmax,$minstep,$majstep]
	// If $majend==true then the first and last marks on the axis will be major
	// labeled tick marks otherwise it will be adjusted to the closest min tick mark
	function CalcTicks($maxsteps,$min,$max,$a,$b,$majend=true) {
		$diff=$max-$min;
		$ld=floor(log10($diff));
		
		// Gravitate min towards zero if we are close		
		if( $min>0 && $min < pow(10,$ld) ) $min=0;
		
		$majstep=pow(10,$ld-1)/$a; 
		$minstep=$majstep/$b;
		$adjmax=ceil($max/$minstep)*$minstep;
		$adjmin=floor($min/$minstep)*$minstep;	
		$adjdiff = $adjmax-$adjmin;
		$numsteps=$adjdiff/$majstep; 
		while( $numsteps>$maxsteps ) {
			$majstep=pow(10,$ld)/$a; 
			$numsteps=$adjdiff/$majstep;
			++$ld;
		}
		$minstep=$majstep/$b;
		$adjmin=floor($min/$minstep)*$minstep;	
		$adjdiff = $adjmax-$adjmin;		
		if( $majend ) {
			$adjmin = floor($min/$majstep)*$majstep;	
			$adjdiff = $adjmax-$adjmin;		
			$adjmax = ceil($adjdiff/$majstep)*$majstep+$adjmin;
		}
		else
			$adjmax=ceil($max/$minstep)*$minstep;
			
		return array($numsteps,$adjmin,$adjmax,$minstep,$majstep);
	}
	
	
	// Determine the minimum of three values witha  weight for last value
	function MatchMin3($a,$b,$c,$weight) {
		if( $a < $b ) {
			if( $a < ($c*$weight) ) 
				return 1; // $a smallest
			else 
				return 3; // $c smallest
		}
		elseif( $b < ($c*$weight) ) 
			return 2; // $b smallest
		return 3; // $c smallest
	}
} // Class

//===================================================
// CLASS RGB
// Description: Color definitions
//===================================================
class RGB {
	var $rgb_table;
	var $img;
	function RGB(&$img) {
		$this->img = $img;
		$this->rgb_table = array(
			"black"		=> array(  0,   0,   0),
			"maroon"		=> array(128,   0,   0),
			"lightgreen"=>	array(144,238,144),			
			"green"		=> array(  0, 128,   0),
			"olive"		=> array(128, 128,   0),
			"navy"      => array(  0,   0, 128),
			"purple"    => array(128,   0, 128),
			"teal"      => array(  0, 128, 128),
			"gray"      => array(128, 128, 128),
			"lightgray"	=>	array(180, 180, 180),
			"silver"    => array(192, 192, 192),
			"red"			=> array(255,   0,   0),
			"lime"		=> array(  0, 255,   0),
			"yellow"		=> array(255, 255,   0),
			"lightyellow"=>array(255,255,224),
			"blue"		=> array(  0,   0, 255),
			"fuchsia"	=> array(255,   0, 255),
			"aqua"		=> array(  0, 255, 255),
			"lightred"	=> array(211, 167, 168),
			"mediumred"	=> array(140,  34,  34),
			"darkred"	=> array( 87,  16,  12),
			"wueste"		=> array(195, 195, 180),
			"gainsboro" => array(220,220,220),			
			"deepskyblue"=>array(0,191,255),
			"seagreen"	=>	array(46,139,87),
			"khaki"		=>	array(240,230,140),			
			"limegreen"	=>	array(50,205,50),
			"indianred" => array(205,92,92),
			"steelblue" =>	array(99,184,255),
			"orange"		=>	array(255,165,0),
			"darkorange"=>	array(255,127,0),
			"cyan"		=>	array(0,255,255),
			"darkcyan"	=>	array(0,139,139),
			"white"		=> array(255, 255, 255));		
	}
//----------------
// PUBLIC METHODS
	function Color($color) {
		if (is_string($color)) {
      	if (substr($color, 0, 1) == "#") {
	  			return array(hexdec(substr($color, 1, 2)), 
		      	hexdec(substr($color, 3, 2)),
		       	hexdec(substr($color, 5, 2)));
      	} else {
	  			return $this->rgb_table[$color];
 			}
		} else {
			return $color;
		}
	}
	function Allocate($color) {
  		list ($r, $g, $b) = $this->color($color);
		$index = imagecolorexact($this->img, $r, $g, $b);
		if ($index == -1) {
      	return imagecolorallocate($this->img, $r, $g, $b);
 		} else {
      	return $index;
  		}
	}
} // Class

//===================================================
// CLASS Image
// Description: Wrapper class with some goodies to form the
// Interface to low level image drawing routines.
//===================================================
class Image {
	var $img_format="png";
	var $expired=false;
	var $img;
	var $left_margin=30,$right_margin=30,$top_margin=20,$bottom_margin=30;
	var $rgb;
	var $current_color;
	var $lastx=0, $lasty=0;
	var $width, $height;
	var $line_weight=1;
	var $obs_list=array();
	var $font_size=2,$font_name="internal";
	//---------------
	// CONSTRUCTOR
	function Image($aWidth,$aHeight,$aFormat="png") {
		assert($aHeight>0 && $aWidth>0);
		$this->img = imagecreate($aWidth, $aHeight);	
		$this->width=$aWidth;
		$this->height=$aHeight;		
		$this->SetMargin($aWidth/10,$aWidth/10,$aHeight/10,$aHeight/10);
		assert($this->img != 0);
		if( !$this->SetImgFormat($aFormat) ) {
			die("Selected graphic format is either not supported or unknown [$aFormat]");
		}
		$this->rgb = new RGB($this->img);		
		
		// First index is background so this will be white
		$this->SetColor("white");
	}
				
	//---------------
	// PUBLIC METHODS	

	// Add observer. The observer will be notified when
	// the margin changes
	function AddObserver($meth,&$obj) {
		$this->obs_list[]=array($meth,&$obj);
	}
	
	function NotifyObservers() {
		foreach( $this->obs_list as $o )
			$o[1]->$o[0](&$this);
	}
	
	function SetFont($size,$name="internal") {
		$this->font_size = $size;
		$this->font_name = $name;
	}
	
	function GetFontHeight() {
		return imagefontheight($this->font_size);
	}
	
	function GetTextWidth(&$txt) {
		return strlen($txt)*imagefontwidth($this->font_size);
	}
	
	function StrokeBoxedText($x,$y,$txt,$halign,$dir,$fcolor,$bcolor,$shadow=false) {
		$marg=3;	// Margin in pixels between the text and the surrounding box
		if( $dir=="v" ) {
			$width=imagefontheight($this->font_size);
			$height=strlen($txt)*imagefontwidth($this->font_size);
		}
		else {
			$width=strlen($txt)*imagefontwidth($this->font_size);
			$height=imagefontheight($this->font_size);
		}
		if( $halign=="right" ) {
			$x -= $width;
		}
		elseif( $halign=="center" ) {
			$x -= $width/2;
		}
		$x1 = $x - $marg;
		$y1 = $y - $marg;
		if( $dir=="v" ) {
			$y1 -= $height;
		}
		$height += 2*$marg;
		$width += 2*$marg;
		if( $shadow ) {
			$oc=$this->SetColor($bcolor);
			$this->ShadowRectangle($x1,$y1,$x1+$width+2,$y1+$height+2,$fcolor,2);
			$this->current_color=$oc;
		}
		else {
			if( $fcolor ) {
				$oc=$this->SetColor($fcolor);
				$this->FilledRectangle($x1,$y1,$x1+$width,$y1+$height);
				$this->current_color=$oc;
			}
			if( $bcolor ) {
				$oc=$this->SetColor($bcolor);			
				$this->Rectangle($x1,$y1,$x1+$width,$y1+$height);
				$this->current_color=$oc;			
			}
		}
		if( $dir=="v" )
			imagestringup($this->img,$this->font_size,$x,$y,$txt,$this->current_color);
		else	
			imagestring($this->img,$this->font_size,$x,$y,$txt,$this->current_color);
	}
				
	function StrokeText($x,$y,$txt,$halign="left",$dir="h") {
		if( $this->font_name == "internal" ) {
			if( $this->font_size > 5 || $this->font_size < 1 )
				$this->font_size = 1;
			if( $dir=="v" )
				$fact=imagefontheight($this->font_size);
			else
				$fact=strlen($txt)*imagefontwidth($this->font_size);
			if( $halign=="right" ) {
				$x -= $fact;
			}
			elseif( $halign=="center" ) {
				$x -= $fact/2;
			}
			if( $dir=="v" )
				imagestringup($this->img,$this->font_size,$x,$y,$txt,$this->current_color);
			else	
				imagestring($this->img,$this->font_size,$x,$y,$txt,$this->current_color);
		}
		else  { // TTF font
			assert(false);
			return false; // Not yet implemented... a 30 min exercise for the interested.
		}
		return true;
	}
		
	function SetMargin($lm,$rm,$tm,$bm) {
		$this->left_margin=$lm;
		$this->right_margin=$rm;
		$this->top_margin=$tm;
		$this->bottom_margin=$bm;
		$this->plotwidth=$this->width - $this->left_margin-$this->right_margin;
		$this->plotheight=$this->height - $this->top_margin-$this->bottom_margin;
		
		$this->NotifyObservers();
	}

	function SetTransparent($color) {
		imagecolortransparent ($this->img,$this->rgb->allocate($color));
	}
	
	function SetColor($color) {
		$oc = $this->current_color;
		$this->current_color=$this->rgb->allocate($color);
		return $oc;
	}
	
	function SetLineWeight($weight) {
		$this->line_weight = $weight;
	}
	
	function SetStartPoint($x,$y) {
		$this->lastx=$x;
		$this->lasty=$y;
	}
	
	function Arc($cx,$cy,$w,$h,$s,$e) {
		imagearc($this->img,$cx,$cy,$w,$h,$s,$e,$this->current_color);
	}

	function Line($x1,$y1,$x2,$y2) {
		if( $this->line_weight==1 )
			imageline($this->img,$x1,$y1,$x2,$y2,$this->current_color);
		else {
			if( $x1 != $x2 ) {
				for($i=0; $i<$this->line_weight; ++$i )
					imageline($this->img,$x1,$y1-$i,$x2,$y2-$i,$this->current_color);
			}
			else {
				for($i=0; $i<$this->line_weight; ++$i )
					imageline($this->img,$x1+$i,$y1,$x2+$i,$y2,$this->current_color);			
			}
		}		
		$lastx=$x2; $lasty=$y2;		
	}
	
	function Polygon($points) {
		imagepolygon($this->img,$points,count($points)/2,$this->current_color);
	}
	
	function FilledPolygon($points) {
		imagefilledpolygon($this->img,$points,count($points)/2,$this->current_color);
	}
	
	function Rectangle($xl,$yu,$xr,$yl) {
		imagerectangle($this->img,$xl,$yu,$xr,$yl,$this->current_color);
	}
	
	function FilledRectangle($xl,$yu,$xr,$yl) {
		imagefilledrectangle($this->img,$xl,$yu,$xr,$yl,$this->current_color);
	}
	
	function ShadowRectangle($xl,$yu,$xr,$yl,$fcolor=false,$shadow_width=3,$shadow_color=array(102,102,102)) {
		if( $fcolor==false )
			$this->Rectangle($xl,$yu,$xr-$shadow_width-1,$yl-$shadow_width-1);
		else {		
			$oc=$this->SetColor($fcolor);
			$this->FilledRectangle($xl,$yu,$xr-$shadow_width-1,$yl-$shadow_width-1);
			$this->current_color=$oc;
			$this->Rectangle($xl,$yu,$xr-$shadow_width-1,$yl-$shadow_width-1);							
		}
		$this->SetColor($shadow_color);
		$this->FilledRectangle($xr-$shadow_width,$yu+$shadow_width,$xr,$yl);
		$this->FilledRectangle($xl+$shadow_width,$yl-$shadow_width,$xr,$yl);
	}
	
	function LineTo($x,$y) {
		$this->Line($this->lastx,$this->lasty,$x,$y);
		$this->lastx=$x;
		$this->lasty=$y;
	}
	
	function Point($x,$y) {
		imagesetpixel($this->img,$x,$y,$this->current_color);
	}
	
	function DashedLine($x1,$y1,$x2,$y2,$dash_length=1,$dash_space=4) {
		// Code based on, but not identical to, work by Ariel Garza and James Pine
		$line_length = ceil (sqrt(pow(($x2 - $x1),2) + pow(($y2 - $y1),2)) );
		$dx = ($x2 - $x1) / $line_length;
		$dy = ($y2 - $y1) / $line_length;
		$lastx = $x1;
		$lasty = $y1;
		for ($i = 0; $i < $line_length; $i += ($dash_length + $dash_space)) {
			$x = ($dash_length * $dx) + $lastx;
			$y = ($dash_length * $dy) + $lasty;
			
			// The last section might overshoot so we must take a computational hit
			// and check this.
			if( $x>$x2 ) $x=$x2;
			if( $y>$y2 ) $y=$y2;
			
			$this->Line($lastx,$lasty,$x,$y);
			$lastx = $x + ($dash_space * $dx);
			$lasty = $y + ($dash_space * $dy);
		} 
	} 
	
	// Generate image header
	function Headers() {
		if ($this->expired) {
			header("Expires: Mon, 26 Jul 1997 05:00:00 GMT");
			header("Last-Modified: " . gmdate("D, d M Y H:i:s") . "GMT");
			header("Cache-Control: no-cache, must-revalidate");
			header("Pragma: no-cache");
		}
		header("Content-type: image/$this->img_format");
	}

	// Stream image to browser or to file
	function Stream($aFile="") {
		$func="image".$this->img_format;
		if( $aFile != "" )
			$func($this->img,$aFile);
		else
			$func($this->img);
	}
		
	// Clear resource tide up by image
	function Destroy() {
		imagedestroy($this->img);
	}
	
	// Specify image format. Note depending on your installation
	// of PHP not all formats may be supported.
	function SetImgFormat($aFormat) {
		$aFormat = strtolower($aFormat);
		if( $aFormat=="jpg" || $aFormat=="png" || $aFormat=="gif" ) {
			if( $aFormat=="jpg" && !(imagetypes() & IMG_JPG) )
				return false;
			elseif( $aFormat=="png" && !(imagetypes() & IMG_PNG) ) 
				return false;
			elseif( $aFormat=="gif" && !(imagetypes() & IMG_GIF) ) 	
				return false;
			else {
				$this->img_format=$aFormat;
				return true;
			}
		}
		else
			return false;
	}	
} // CLASS

//===================================================
// CLASS ImgStreamCache
// Description: Handle caching of graphs to files
//===================================================
class ImgStreamCache {
	var $cache_dir;
	var $img=null;
	//---------------
	// CONSTRUCTOR
	function ImgStreamCache(&$aImg, $aCacheDir=CACHE_DIR) {
		$this->img = &$aImg;
		$this->cache_dir = $aCacheDir;
	}

//---------------
// PUBLIC METHODS	

	// Output image to browser and also cache it
	function PutAndStream(&$aImage,$aFile) {
		if( $aFile != "" ) {
			$aFile = $this->cache_dir . "/$aFile";
			if (file_exists($aFile))
				unlink($aFile);
			$this->_MakeDirs(dirname($aFile));
			$aImage->Stream($aFile);
			$aImage->Destroy();
			if ($fh = fopen($aFile, "r")) {
				$this->img->Headers();
				fpassthru($fh);
				exit();
	 		} 
	 	}
	 	else {
			$this->img->Headers();	 		
	 		$aImage->Stream();	
	 		return false;
	 	}
	}
	
	// Check if a given image is in cache and in that case
	// pass it on to webb browser
	function GetAndStream($aFile) {
		$aFile = $this->cache_dir . "/".$aFile;	
	 	if ( file_exists($aFile) ) {
			if ($fh = fopen($aFile, "r")) {
				$this->img->Headers();
				fpassthru($fh);
				return true;
			}
		} 
	 	return false;
	}
	
	//---------------
	// PRIVATE METHODS	
	function _MakeDirs($aFile) {
		while (! (file_exists($aFile))) {
			$dirs[] = $aFile;
			$aFile = dirname($aFile);
	 	}
	 	for ($i = sizeof($dirs)-1; $i>=0; $i--) 
			mkdir($dirs[$i], 0777);
		return true;
	}	
} // CLASS Cache
	
//===================================================
// CLASS Legend
// Description: Responsible for drawing the box containing
// all the legend text for the graph
//===================================================
class Legend {
	var $color=array(0,0,0),$fill_color=array(255,255,176),$shadow=true;
	var $txtcol=array();
	var $mark_abs_size=10,$xmargin=5,$ymargin=5,$shadow_width=2;
	var $xpos=0.05, $ypos=0.05, $halign="right", $valign="top";
	var $font="internal",$font_size=2;
	var $hide=false,$layout=LEGEND_VERT;
//---------------
// CONSTRUCTOR
	function Legend() {
	}
//---------------
// PUBLIC METHODS	
	function Hide($f=true) {
		$this->hide=$f;
	}
	
	function SetShadow($f=true,$width=2) {
		$this->shadow=$f;
		$this->shadow_width=$width;
	}
	
	function SetLayout($l=LEGEND_VERT) {
		$this->layout=$l;
	}
	
	function SetFont($size,$font="internal") {
		$this->font=$font;
		$this->font_size=$size;
	}
	
	function Pos($x,$y,$halign="right",$valign="top") {
		assert($x<1 && $y<1);
		$this->xpos=$x;
		$this->ypos=$y;
		$this->halign=$halign;
		$this->valign=$valign;
	}

	function SetBackground($c) {
		$this->fill_color=$c;
	}

	function Add($txt,$color) {
		$this->txtcol[]=array($txt,$color);
	}
	
	function Stroke(&$img,&$xscale,&$yscale) {
		if( $this->hide ) return;
		$nbrplots=count($this->txtcol);
		if( $nbrplots==0 ) return;
		$img->SetFont($this->font_size);	
		if( $this->layout==LEGEND_VERT )		
			$abs_height=$img->GetFontHeight() + $this->mark_abs_size*$nbrplots +
						$this->ymargin*($nbrplots-1);
		else
			$abs_height=2*$this->mark_abs_size+$this->ymargin;
						
		if( $this->shadow ) $abs_height += $this->shadow_width;
		
		$mtw=0;
		foreach($this->txtcol as $p) {
			if( $this->layout==LEGEND_VERT )
				$mtw=max($mtw,$img->GetTextWidth($p[0]));
			else
				$mtw+=$img->GetTextWidth($p[0])+$this->mark_abs_size+$this->xmargin;
		}
		$abs_width=$mtw+2*$this->mark_abs_size+2*$this->xmargin;
		if( $this->halign=="left" )
			$xp=$this->xpos*$img->width;
		elseif( $this->halign=="center" )
			$xp=$this->xpos*$img->width - $abs_width/2; 
		else  
			$xp = $img->width - $this->xpos*$img->width - $abs_width;
		$yp=$this->ypos*$img->height;
		if( $this->valign=="center" )
			$yp-=$abs_height/2;
		$img->SetColor($this->color);				
		if( $this->shadow )
			$img->ShadowRectangle($xp,$yp,$xp+$abs_width,$yp+$abs_height,$this->fill_color,$this->shadow_width);
		else {
			$img->SetColor($this->fill_color);				
			$img->FilledRectangle($xp,$yp,$xp+$abs_width,$yp+$abs_height);
			$img->SetColor($this->color);				
			$img->Rectangle($xp,$yp,$xp+$abs_width,$yp+$abs_height);
		}
					 
		$x1=$xp+$this->mark_abs_size/2;
		$y1=$yp+$img->GetFontHeight()*0.5;
		foreach($this->txtcol as $p) {
			$img->SetColor($p[1]);
			$img->FilledRectangle($x1,$y1,$x1+$this->mark_abs_size,$y1+$this->mark_abs_size);
			$img->SetColor($this->color);
			$img->Rectangle($x1,$y1,$x1+$this->mark_abs_size,$y1+$this->mark_abs_size);			
			$img->StrokeText($x1+$this->mark_abs_size+$this->xmargin,$y1,$p[0]);
			if( $this->layout==LEGEND_VERT )
				$y1 += $this->ymargin+$this->mark_abs_size;
			else
				$x1 += 2*$this->ymargin+$this->mark_abs_size+$img->GetTextWidth($p[0]);
		}											 								 
	}
//---------------
// PRIVATE METHODS	
} // Class
	
//===================================================
// CLASS Plot
// Description: Abstract base class for all concrete plot classes
//===================================================
class Plot {
	var $line_weight=1;
	var $coords=array();
	var $legend="";
	var $color=array(0,0,0);
	var $numpoints=0;
	var $weight=1;	
//---------------
// CONSTRUCTOR
	function Plot(&$datay,$datax=false) {
		$this->numpoints = count($datay);
		$this->coords[0]=$datay;
		if( is_array($datax) )
			$this->coords[1]=$datax;
	}

//---------------
// PUBLIC METHODS	

	// Stroke the plot
	// "virtual" function which must be implemented by
	// the subclasses
	function Stroke(&$img,&$xscale,&$yscale) {
		return true;
	}
	
	// The chance for each plot class to set a legend
	function Legend(&$graph) {
		if( $this->legend!="" )
			$graph->legend->Add($this->legend,$this->color);		
	}
	
	// "Virtual" function which gets called before any scale
	// or axis are stroked used to do any plot specific adjustment
	function PreStrokeAdjust(&$graph) {	
		return true;	
	}
	
	function SetWeight($weight) {
		$this->weight=$weight;
	}
	
	function Min() {
		$x=$this->coords[1];
		if( count($x) > 0 )
			$xm=min($x);
		else 
			$xm=0;
		$y=$this->coords[0];
		if( count($y) > 0 )
			$ym=min($y);
		else 
			$ym=0;
		return array($xm,$ym);
	}
	
	function Max() {
		$x=$this->coords[1];
		if( count($x) > 0 )
			$xm=max($x);
		else 
			$xm=count($this->coords[0]);
		$y=$this->coords[0];
		if( count($y) > 0 )
			$ym=max($y);
		else 
			$ym=0;
		return array($xm,$ym);
	}
	
	function SetColor($color) {
		$this->color=$color;
	}
	
	function SetLegend($aLegend) {
		$this->legend = $aLegend;
	}
	
	function SetLineWeight($weight=1) {
		$this->line_weight=$weight;
	}
	
	// This method gets called by Graph class to plot anything that should go
	// into the margin after the margin color has been set.
	function StrokeMargin(&$img) {
		return true;
	}
} // Class
?>