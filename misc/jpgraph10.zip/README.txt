README FOR JPGRAPH 1.0
======================

This ZIP contains JpGraph 1.0 an Object Oriented PHP4 Graph Plotting library.
The library is released under GPL 2.0

Included files
--------------
README.txt			This file
jpgraph.zip			Base library
jpgraph_log.php			Extension to handle logarithmic scales
jpgraph_line.php		Extension to handle various types of line plots 
jpgraph_bar			Extension to handle various types of bar plots
jpgraph_error			Extension to handle various types of error plots
gpl.txt				GPL 2.0	Licensee


Documentation
-------------
The latest documentation, both on-line, and offline may be found at
http://www.aditus.nu/jpgraph/

Bug reports and suggestions
---------------------------
Should be sent to jpgraph@aditus.nu

Change history
------------------------------------------------------------------------
Date			Ver		Comment
------------------------------------------------------------------------
2001-02-04	1.0		First public release




Happy Graphing!
Stockholm/London 2001-02-04
Johan Persson